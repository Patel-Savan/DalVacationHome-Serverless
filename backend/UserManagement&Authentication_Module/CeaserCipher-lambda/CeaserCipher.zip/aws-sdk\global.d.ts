import {GlobalConfigInstance} from './lib/config'; 

export * from './lib/core';
export var config: GlobalConfigInstance